import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useParams } from "react-router-dom";
    
const Detail = (props) => {
    const [product, setProduct] = useState(null)
    const { id } = useParams();
    
    useEffect(() => {
        axios.get('http://localhost:8000/api/products/' +id)
            .then(res => {setProduct(res.data.product)
            console.log(res)})
            .catch(err => console.error(err));
    }, [id]);
    
    return (
        product ?
        <div> 
            <p>Title: {product.title}</p>
            <p>Price: ${product.price}</p>
            <p>Description: {product.description}</p>
        </div> : <p> loading in process.. </p>
    )

}

{/* <div>
    <Link to={`/products/update/${product._id}`}>Edit</Link>
    <button onClick={(e) => {deleteProduct(product._id)}}>Delete</button>

</div> */}

    
export default Detail;

