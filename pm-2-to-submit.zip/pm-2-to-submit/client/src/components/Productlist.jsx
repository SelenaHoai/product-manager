import React from 'react'
import {Link} from 'react-router-dom'

const Productlist = (props) => {
    console.log(props)



    return (
        <div>{
            props.allDaProducts.map((product) => {
                return ( 
                <div key={product._id}>
                    <div style={{margin:5, fontSize:18}}>
                        <Link to={`/products/${product._id}`}>{product.title}</Link>
                    </div>
                </div>
                )
            })
        }</div>
    )
}


export default Productlist



